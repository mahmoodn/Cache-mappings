package m1179.arch

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.math.log2

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val animationDuration: Long = 1250
        about.setOnClickListener {


            val dialog = AlertDialog.Builder(this)
                .setCancelable(true)
                .setTitle("mohammad alizadeh")
                .setMessage("Shahid Chamran University of Ahvaz\n\nm.alizadeh.1179@gmail.com")
                .setPositiveButton("OK") { _, _ -> }
                .setIcon(R.drawable.logo)
                .setNegativeButton("website"){_ , _ ->
                    startActivity(Intent(Intent.ACTION_VIEW ,
                        Uri.parse("http://scu.ac.ir")))
                }
                .create()
            dialog.window?.attributes?.windowAnimations = R.style.alert
            dialog.show()
        }

        sa.setOnCheckedChangeListener { _, isChecked ->
            raw.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        val share = getSharedPreferences("values", Context.MODE_PRIVATE)

        with(share) {
            mmb.isChecked = getBoolean("mmb", false)
            cmb.isChecked = getBoolean("cmb", false)
            memorySize.setText(getString("memorySize", ""))
            cacheSize.setText(getString("cacheSize", ""))
            blockSize.setText(getString("blockSize", ""))
            accessTime.setText(getString("accessTime", ""))
            penaltyTime.setText(getString("penaltyTime", ""))
            when (getInt("mode", 1)) {
                1 -> dm.isChecked = true
                2 -> {
                    sa.isChecked = true
                    raw.visibility = View.VISIBLE
                }
                3 -> fa.isChecked = true
            }
            raw.setText(getString("raw", ""))
        }

        submit.setOnClickListener {
            if (memorySize.text.isBlank() ||
                cacheSize.text.isBlank() ||
                blockSize.text.isBlank() ||
                accessTime.text.isBlank() ||
                penaltyTime.text.isBlank() ||
                (sa.isChecked && raw.text.isBlank())
            ) {

                val dialog = AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle("ERROR")
                    .setMessage("please complete all fields !")
                    .setPositiveButton("OK") { _, _ -> }
                    .create()
                dialog.window?.attributes?.windowAnimations = R.style.alert
                dialog.show()

            } else if (!sizeValid()) {
                val dialog = AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle("ERROR")
                    .setMessage("cache size must be less than memory size !")
                    .setPositiveButton("OK") { _, _ -> }
                    .create()
                dialog.window?.attributes?.windowAnimations = R.style.alert
                dialog.show()

            } else if (!validateB(
                    Integer.parseInt(memorySize.text.toString()) * 1024.0 * if (mmb.isChecked) 1024 else 1,
                    Integer.parseInt(cacheSize.text.toString()) * 1024.0 * if (mmb.isChecked) 1024 else 1,
                    Integer.parseInt(blockSize.text.toString()) * 1.0,
                    if (raw.text.isEmpty()) 1.0 else
                        Integer.parseInt(raw.text.toString()) * 1.0
                )
            ) {

                val dialog = AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle("ERROR")
                    .setMessage("size fields must be binary !")
                    .setPositiveButton("OK") { _, _ -> }
                    .create()
                dialog.window?.attributes?.windowAnimations = R.style.alert
                dialog.show()

            } else {

                with(share.edit()) {
                    putBoolean("mmb", mmb.isChecked)
                    putBoolean("cmb", cmb.isChecked)
                    putString("memorySize", memorySize.text.toString()).apply()
                    putString("cacheSize", cacheSize.text.toString())
                    putString("blockSize", blockSize.text.toString())
                    putString("accessTime", accessTime.text.toString())
                    putString("penaltyTime", penaltyTime.text.toString())
                    putInt("mode", if (dm.isChecked) 1 else if (sa.isChecked) 2 else 3)
                    putString("raw", raw.text.toString())
                    apply()
                }

                startActivity(
                    Intent(baseContext, Main2Activity::class.java)
                        .putExtra(
                            "memorySize", Integer.parseInt(memorySize.text.toString())
                                    * 1024.0 * if (mmb.isChecked) 1024 else 1
                        )
                        .putExtra(
                            "cacheSize", Integer.parseInt(cacheSize.text.toString())
                                    * 1024.0 * if (cmb.isChecked) 1024 else 1
                        )
                        .putExtra("blockSize", Integer.parseInt(blockSize.text.toString()) * 1.0)
                        .putExtra("accessTime", Integer.parseInt(accessTime.text.toString()))
                        .putExtra("penaltyTime", Integer.parseInt(penaltyTime.text.toString()))
                        .putExtra(
                            "raw", if (sa.isChecked) Integer.parseInt(raw.text.toString())
                            else if (dm.isChecked) -1 else -2
                        )
                )
            }


        }




        mem.animate().translationY(0f).duration = animationDuration
        cache.animate().translationX(0f).duration = animationDuration
        block.animate().translationX(0f).duration = animationDuration
        access.animate().translationX(0f).duration = animationDuration
        penalty.animate().translationX(0f).duration = animationDuration
        model.animate().translationX(0f).duration = animationDuration
        submit.animate().translationX(0f).duration = animationDuration
        about.animate().translationX(0f).duration = animationDuration


    }

    private fun sizeValid(): Boolean {
        val m = Integer.parseInt(memorySize.text.toString()) * 1024 * if (mmb.isChecked) 1024 else 1
        val c = Integer.parseInt(cacheSize.text.toString()) * 1024 * if (cmb.isChecked) 1024 else 1

        return m > c
    }

    private fun validateB(vararg numbers: Double): Boolean {

        for (i in numbers.indices) {
            if (log2(numbers[i]) - log2(numbers[i]).toInt() != 0.0)
                return false
        }
        return true
    }
}
