package m1179.arch

import android.graphics.Color
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main2.*
import kotlin.math.log2
import kotlin.math.pow

class Main2Activity : AppCompatActivity() {

    data class Cache(var tag: String, var index: String, var offset: String)

    data class SA(var index: String, var data: ArrayList<Cache>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val raw = intent.getIntExtra("raw", 0)
        var accessenum = 0f
        var hits = 0f
        textView.movementMethod = ScrollingMovementMethod()
        val data = arrayListOf<Cache>()
        val saData = arrayListOf<SA>()
        val addressLength = log2(intent.getDoubleExtra("memorySize", 0.0))
        val offsetBits = log2(intent.getDoubleExtra("blockSize", 0.0))
        val indexBits = log2(
            intent.getDoubleExtra("cacheSize", 0.0) /
                    intent.getDoubleExtra("blockSize", 0.0) / if (raw != -1 && raw != -2) raw
            else 1
        )
        val tagBits = addressLength - (indexBits + offsetBits)

        var tag = ""
        var index = ""
        var offset = ""


        step.setOnClickListener {
            accessenum++
            var address = editText.text.toString()
            val exAddress = StringBuilder()


            if (address.length < addressLength / 4) {
                for (i in 0 until (addressLength / 4 - address.length).toInt())
                    address = "0$address"
            }
            address = address.substring(0,addressLength.toInt()/4)
            for (i in address.indices)

                when (address[i]) {
                    '0' -> exAddress.append("0000")
                    '1' -> exAddress.append("0001")
                    '2' -> exAddress.append("0010")
                    '3' -> exAddress.append("0011")
                    '4' -> exAddress.append("0100")
                    '5' -> exAddress.append("0101")
                    '6' -> exAddress.append("0110")
                    '7' -> exAddress.append("0111")
                    '8' -> exAddress.append("1000")
                    '9' -> exAddress.append("1001")
                    'a' -> exAddress.append("1010")
                    'b' -> exAddress.append("1011")
                    'c' -> exAddress.append("1100")
                    'd' -> exAddress.append("1101")
                    'e' -> exAddress.append("1110")
                    'f' -> exAddress.append("1111")
                    'A' -> exAddress.append("1010")
                    'B' -> exAddress.append("1011")
                    'C' -> exAddress.append("1100")
                    'D' -> exAddress.append("1101")
                    'E' -> exAddress.append("1110")
                    'F' -> exAddress.append("1111")
                    else -> {
                        address = "${address.substring(0 , i)}0${address.substring(i+1)}"
                        exAddress.append("0000")
                    }
                }

            tag = exAddress.substring(0, tagBits.toInt())
            index = exAddress.substring(tagBits.toInt(), tagBits.toInt() + indexBits.toInt())
            offset = exAddress.substring(tagBits.toInt() + indexBits.toInt(), exAddress.length)

            if (raw == -2){
                tagT.text = "tag\n${tag+index}"
            }
            else {
                tagT.text = "tag\n$tag"
                indexT.text = "index\n$index"
            }
            offsetT.text = "BO\n$offset"


            if (raw == -1) {

                // dm
                var b = true
                for (i in data.indices) {
                    if (data[i].index == index) {
                        if (data[i].tag == tag) {
                            hits++
                            b = false
                            textView.text = ("0x$address -> hit\n"
                                    + textView.text)
                            pre.setTextColor(Color.parseColor("#03DAC5"))
                            pre.text = "previous access :  0x$address -> hit"

                            //hit
                        } else {
                            b = false
                            for (j in data.indices)
                                if (data[j].index == index)
                                    data[j].tag = tag
                            textView.text = ("cache replace\n0x$address -> miss\n"
                                    + textView.text)
                            pre.setTextColor(Color.CYAN)
                            pre.text = "previous access :  0x$address -> miss-replace"
                            //miss replace
                        }
                        break
                    }
                    if (i == data.size - 1) {
                        textView.text = ("0x$address -> miss\n"
                                + textView.text)
                        pre.setTextColor(Color.RED)
                        pre.text = "previous access :  0x$address -> miss"
                    }
                }
                if (data.size == 0) {
                    textView.text = "0x$address -> miss"
                    pre.setTextColor(Color.RED)
                    pre.text = "previous access :  0x$address -> miss"
                }
                if (b)
                    data.add(Cache(tag, index, offset))
            } else if (raw == -2) {

                // fa

                val cacheArraySize = (intent.getDoubleExtra("cacheSize", 0.0) * 1024 /
                        intent.getDoubleExtra("blockSize", 1.0)).toInt()

                if (search(data, tag, index) != -1) {
                    // if was in cache
                    hits++
                    var target = search(data, tag, index)
                    textView.text = ("0x$address -> hit\n"
                            + textView.text)
                    pre.setTextColor(Color.parseColor("#03DAC5"))
                    pre.text = "previous access :  0x$address -> hit"

                    //hit

                    var tempCache = data[target]
                    data.removeAt(target)
                    data.add(tempCache)

                } else {

                    if (data.size == cacheArraySize)
                        data.removeAt(0)

                    textView.text = ("0x$address -> miss\n"
                            + textView.text)
                    pre.setTextColor(Color.RED)
                    pre.text = "previous access :  0x$address -> miss"

                    data.add(Cache(tag, index, offset))

                }

            } else {
                /// sa

                var b = true

                var indexa = index.substring(log2(raw * 1.0).toInt(), index.length)


                for (i in saData.indices) {

                    if (indexa == saData[i].index) {

                        if (search(saData[i].data, tag, index) != -1) {

                            var tar = search(saData[i].data, tag, index)
                            b = false
                            hits++
                            textView.text = ("0x$address -> hit in way no.$tar\n"
                                    + textView.text)
                            pre.setTextColor(Color.parseColor("#03DAC5"))
                            pre.text = "previous access :  0x$address -> hit in way no.$tar"


                            var tempCache = saData[i].data[tar]
                            saData[i].data.removeAt(tar)
                            saData[i].data.add(tempCache)


                        } else {

                            b = false
                            textView.text = ("0x$address -> miss\n"
                                    + textView.text)
                            pre.setTextColor(Color.RED)
                            pre.text = "previous access :  0x$address -> miss"


                            if (saData[i].data.size == raw) {
                                saData[i].data.removeAt(0)
                            }

                            saData[i].data.add(Cache(tag, index, offset))

                        }


                        break
                    }


                }

                if (b) {
                    textView.text = ("0x$address -> miss\n"
                            + textView.text)
                    pre.setTextColor(Color.RED)
                    pre.text = "previous access :  0x$address -> miss"

                    saData.add(SA(indexa, ArrayList()))
                    saData[saData.size - 1].data.add(Cache(tag, index, offset))
                }


            }

            fields.text =
                "av.Access Time -> ${
                if (accessenum != 0f)
                    intent.getIntExtra("accessTime", 0) +
                            intent.getIntExtra("penaltyTime", 0) *
                            ((accessenum - hits) / accessenum)
                else { 0 }
                } ns"
        }

        val animationDuration : Long = 1250
        editText.animate().translationX(0f).duration = animationDuration
        xx.animate().translationX(0f).duration = animationDuration
        step.animate().translationX(0f).duration = animationDuration
        fields.animate().translationX(0f).duration = animationDuration

    }

    private fun search(a: ArrayList<Cache>, tag: String, index: String): Int {

        for (i in a.indices) {
            if (a[i].index == index && a[i].tag == tag) return i
        }
        return -1
    }
}
