import math
import re
import os
from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox
from tkinter.filedialog import asksaveasfile
from datetime import datetime
import sys

ListOfAddresses = []
ListOfCacheBlocks = []
Temp = []
MemorySize = 0
CacheSize = 0
BlockSize = 0
numberOfBlocks = 0
numberOfSets = 0
InfoDM = []
InfoFA = []
InfoSA = []

class CacheBlock(object):
    def __init__(self, index, validity, tag):
        self.index = index
        self.validity = validity
        self.tag = tag
        self.way = []

class Address(object):
    def __init__(self, address, tag, index, byteOffset, situation, numberOfWay):
        self.address = address
        self.tag = tag
        self.index = index
        self.byteOffset = byteOffset
        self.situation = situation
        self.numberOfWay = numberOfWay


def isPowerOfTwo(num):  # check if the number is power of 2 or not...
    if num == 0:
        return False
    while num != 1:
        if num % 2 != 0:
            return False
        num = num // 2
    return True


def Show(add):  # show the details of input address
    txt = "Input is : " + add.address + "Edited address : " + (add.tag + add.index + add.byteOffset) + "\n" + "\nTag : " + add.tag + \
    "\n" + "Index : " + add.index + "\n" + "Byte Offset : " + add.byteOffset + "\n" + "Situation : " + add.situation + "\n"
    messagebox.showinfo(title="Details", message=txt)
    InfoDM.append(txt)


def Searching(address):  # search to find block in cache...
    if len(ListOfCacheBlocks) != 0:

        for block in ListOfCacheBlocks:

            if block.index == address.index:  # for entering second address and so on...

                if block.tag == address.tag:
                    address.situation = "Hit"
                    return True
                else:
                    address.situation = " Miss (Replacement)"
                    block.tag = address.tag  # replacement
                    return True
    else:
        return False


def CheckingCache(address):  # finding block
    if not Searching(address):
        ListOfCacheBlocks.append(CacheBlock(address.index, 1, address.tag))  # Create new block.
        address.situation = "Miss"
    Show(address)


def Separation(inputAdd, address, length, cacheSize, blockSize):  # separate parts of address
    indexSize = int(math.log2(int(cacheSize / blockSize)))  # Calculating index size and offset size and tag size.
    offsetSize = int(math.log2(blockSize))
    tagSize = length - (indexSize + offsetSize)

    add = Address(inputAdd, address[0:tagSize],
                  address[tagSize:tagSize + indexSize], address[tagSize + indexSize:len(address)], "", "")
    ListOfAddresses.append(add)  # adding address into array of addresses...
    CheckingCache(add)


def Initializing():  # Initializing variables.
    global MemorySize
    global CacheSize
    global BlockSize
    txt = ""
    txt1 = ""
    if len(ListOfAddresses) == 0:  # Calculating sizes for the first time.

        try :
            if memorytxt.get() != "":

                MemorySize = int(memorytxt.get())  # Calculating memory size.
                if formatcb1.get() == "GB":
                    MemorySize = MemorySize * pow(2, 30)
                elif formatcb1.get() == "MB":
                    MemorySize = MemorySize * pow(2, 20)
                elif formatcb1.get() == "KB":
                    MemorySize = MemorySize * pow(2, 10)
                else:
                    txt1 = txt1 + " memory combo box"
            else:
                txt =  txt + " memory size" 


            if cachetxt.get() != "":

                CacheSize = int(cachetxt.get())  # Calculating cache size.
                if formatcb2.get() == "MB":
                    CacheSize = CacheSize * pow(2, 20)
                elif formatcb2.get() == "KB":
                    CacheSize = CacheSize * pow(2, 10)
                else:
                    if txt1 == "":
                        txt1 = txt1 + " cache combo box"
                    else:
                        txt1 = txt1 + " and cache combo box"     
            else:
                if txt == "":
                    txt = txt + " cache size" 
                else:
                    txt = txt + " , cache size"


            if blocktxt.get() != "":
                BlockSize = int(blocktxt.get())  # Calculating block size.
            else:
                if txt == "":
                    txt = txt + " block size" 
                else:
                    txt = txt + " and block size"


            if txt != "" and txt1 != "":
                messagebox.showerror(title="Error", message="Enter" + txt + "." + "\n" + "Choose" + txt1 + ".")

            elif txt != "" and txt1 == "":
                    messagebox.showerror(title="Error", message="Enter" + txt + "." )
            
            elif txt == "" and txt1 != "":
                messagebox.showerror(title="Error", message="Choose" + txt1 + ".")
        except ValueError:
            messagebox.showerror(title="Error", message="Enter valid input for memory/cache/block size !")


def DirectMap():  # Get inputs and change Hex address to Binary address...

    global MemorySize
    global CacheSize
    global BlockSize
    Initializing()  # Initializing variables.
    # check if the inputs are power of 2...
    if isPowerOfTwo(MemorySize) and isPowerOfTwo(CacheSize) and isPowerOfTwo(BlockSize):

        if MemorySize > CacheSize:
            regex = re.findall("^0[xX].[a-fA-F0-9]*$", addresstxt.get())  # Match input with regEX.
            if regex:
                try:
                    Length = int(math.log2(MemorySize))  # Length of addresses in memory.
                    res = "{0:08b}".format(int(addresstxt.get(), 16))  # Code to convert hex to binary
                    # code for solving the problem of length of input address!
                    res = res[::-1]
                    for j in range(((len(addresstxt.get()) - 2) * 4) - len(res)):
                        res = res + str(0)
                    res = res[::-1]
                    # code for adding 0 to the address.
                    if len(res) < Length:
                        InputAddress = res + " (This address is short)" + "\n"
                        res = res[::-1]
                        for x in range(Length - len(res)):
                            res = res + str(0)
                        res = res[::-1]
                        Separation(InputAddress, res, Length, CacheSize, BlockSize)

                    elif len(res) == Length:
                        InputAddress = res + "\n"
                        Separation(InputAddress, res, Length, CacheSize, BlockSize)

                    else:
                        InputAddress = res + " (This address is long)" + "\n"
                        res = res[len(res) - Length:len(res)]  # if the address is long.
                        Separation(InputAddress, res, Length, CacheSize, BlockSize)
                    memorytxt.configure(state="disable")  # Disable all entries to be unchangeable during execution.
                    cachetxt.configure(state="disable")
                    blocktxt.configure(state="disable")
                    formatcb1.configure(state="disable")
                    formatcb2.configure(state="disable")
                    rad1.configure(state="disable")
                    rad2.configure(state="disable")
                    rad3.configure(state="disable")
                except ValueError:
                    messagebox.showerror(title="Error", message="Address is not valid !")
            else:
                messagebox.showerror(title="Address is not valid !", message="Please use (0x) at the "
                                                                            "first of your input or "
                                                                            "enter valid input.")
        else:
            messagebox.showerror(title="Error", message="Memory must be greater than cache !")
            memorytxt.delete(0, END)
            cachetxt.delete(0, END)
    else:
        if memorytxt.get() != "" and cachetxt.get() != "" and blocktxt.get() != "":
            messagebox.showerror(title="Error", message="Some of the inputs are not power of 2...!")
        MemorySize = 0
        CacheSize = 0
        BlockSize = 0
    addresstxt.delete(0, END)
    addresstxt.insert(0, "0x")


def find(tag):
    for Add in ListOfCacheBlocks:
        if Add.tag == tag:
            return True
    return False


def search(arr, n, x):
    for i in range(0, n):
        if arr[i] == x:
            return True
    return False


def FullyAssociative():
    victim = ""
    global MemorySize
    global CacheSize
    global BlockSize
    global numberOfBlocks
    Initializing()  # Initializing variables.
    if BlockSize != 0:
        numberOfBlocks = int(CacheSize / BlockSize)
    # check if the inputs are power of 2...
    if isPowerOfTwo(MemorySize) and isPowerOfTwo(CacheSize) and isPowerOfTwo(BlockSize):

        if MemorySize > CacheSize:
            regex = re.findall("^0[xX].[a-fA-F0-9]*$", addresstxt.get())  # Match input with regEX.
            if regex:
                try:
                    Length = int(math.log2(MemorySize))  # Length of addresses in memory.
                    res = "{0:08b}".format(int(addresstxt.get(), 16))  # Code to convert hex to binary
                    # code for solving the problem of length of input address!
                    res = res[::-1]
                    for j in range(((len(addresstxt.get()) - 2) * 4) - len(res)):
                        res = res + str(0)
                    res = res[::-1]
                    InputAddress = res 

                    if len(res) < Length:
                        res = res[::-1]
                        for x in range(Length - len(res)):
                            res = res + str(0)
                        res = res[::-1]
                    elif len(res) > Length:
                        res = res[len(res) - Length:len(res)]  # if the address is long.

                    # start
                    tagSize = Length - int(math.log2(BlockSize))
                    tag = res[0:tagSize]
                    offset = res[tagSize:len(res)] 

                    if len(ListOfAddresses) == 0:
                        Add = Address(res, tag, "", offset, "Miss", "")
                        ListOfAddresses.append(Add)
                        ListOfCacheBlocks.append(Add)

                    else:

                        if find(tag):
                            Add = Address(res, tag, "", offset, "Hit", "")
                            ListOfAddresses.append(Add)
                        else:
                            Add = Address(res, tag, "", offset, "Miss", "")
                            ListOfAddresses.append(Add)
                            ListOfCacheBlocks.append(Add)
                            if len(ListOfCacheBlocks) > numberOfBlocks:

                                for i in range(len(ListOfAddresses) - 2, -1, -1):

                                    if len(Temp) == 0:

                                        Temp.append(ListOfAddresses[i].tag)

                                    else:

                                        for j in range(0, len(Temp)):

                                            if not search(Temp, len(Temp), ListOfAddresses[i].tag):

                                                Temp.append(ListOfAddresses[i].tag)

                                                if len(Temp) == numberOfBlocks:

                                                    victim = Temp[numberOfBlocks - 1]

                                                    for v in range(len(ListOfCacheBlocks) - 1, -1, -1):

                                                        if v < len(ListOfCacheBlocks):

                                                            if victim == ListOfCacheBlocks[v].tag:
                                                                victim = ListOfCacheBlocks[v].address
                                                                ListOfCacheBlocks.pop(v)
                                                                ListOfCacheBlocks.pop(len(ListOfCacheBlocks) - 1)
                                                                Add1 = Address(res, tag, "", offset, "Miss", "")
                                                                ListOfCacheBlocks.insert(v, Add1)
                                                    break
                    txt = "Input is : "+ InputAddress + "\nEdited address : " + Add.address + "\n" + "\nTag : " + Add.tag + "\n" + "Offset : " + Add.byteOffset + "\n" + \
                     "Situation : " + Add.situation + "\n" + "Victim address : " + str(victim) + "\n"
                    messagebox.showinfo(title="Details", message=txt)
                    InfoFA.append(txt)
                    Temp.clear()

                    # finish
                    memorytxt.configure(state="disable")  # Disable all entries to be unchangeable during execution.
                    cachetxt.configure(state="disable")
                    blocktxt.configure(state="disable")
                    formatcb1.configure(state="disable")
                    formatcb2.configure(state="disable")
                    rad1.configure(state="disable")
                    rad2.configure(state="disable")
                    rad3.configure(state="disable")
                except ValueError:
                    messagebox.showerror(title="Error", message="Address is not valid !")
            else:
                messagebox.showerror(title="Address is not valid!", message="Please use (0x) at the "
                                                                            "first of your input or "
                                                                            "enter valid input.")
        else:
            messagebox.showerror(title="Error", message="Memory must be greater than cache !")
            memorytxt.delete(0, END)
            cachetxt.delete(0, END)
    else:
        if memorytxt.get() != "" and cachetxt.get() != "" and blocktxt.get() != "":
            messagebox.showerror(title="Error", message="Some of the inputs are not power of 2...!")
        MemorySize = 0
        CacheSize = 0
        BlockSize = 0
    addresstxt.delete(0, END)
    addresstxt.insert(0, "0x")


def Show1(add):  # show the details of input address
    txt = "Address : " + add.address + "\n" + "\nTag : " + add.tag + "\n" + "Index : " + add.index + "\n" + \
           "Offset : " + add.byteOffset + "\nway " + add.numberOfWay + "\n" + "Situation : " + add.situation + "\n"
    messagebox.showinfo(title="Details", message=txt)
    InfoSA.append(txt)


def Separation1(res, lengthOfAddress, cacheSize, blockSize, numbOfWays):  # separate parts of address

    global numberOfSets

    if len(ListOfAddresses) == 0:
        numberOfSets = int(math.log2(cacheSize / (blockSize * int(numbOfWays))))

    offsetSize = int(math.log2(blockSize))
    indexSize = numberOfSets
    tagSize = lengthOfAddress - (indexSize + offsetSize)
    tag = res[0:tagSize]
    index = res[tagSize:tagSize + indexSize]
    offset = res[tagSize + indexSize:len(res)]

    Add = Address(res, tag, index, offset, "", "")
    ListOfAddresses.append(Add)  # adding address into array of addresses...

    CheckingCache1(Add, numbOfWays)


def Searching1(address, numbOfWays):  # search to find block in cache...

    if len(ListOfCacheBlocks) != 0:

        for block in ListOfCacheBlocks:

            if block.index == address.index:

                if CheckingWays(address, block):

                    return True

                else:
                    address.situation = "Miss"
                    block.way.append(address.tag)
                    address.numberOfWay = str(len(block.way))
                    if len(block.way) > int(numbOfWays):

                        for i in range(len(ListOfAddresses) - 2, -1, -1):

                            if ListOfAddresses[i].index == block.index:

                                if not search(Temp, len(Temp), ListOfAddresses[i].tag):

                                    Temp.append(ListOfAddresses[i].tag)

                                    if len(Temp) == int(numbOfWays):

                                        victim = Temp[int(numbOfWays) - 1]

                                        for v in range(len(block.way) - 1, -1, -1):

                                            if v < len(block.way):

                                                if victim == block.way[v]:
                                                    victim = block.way[v]
                                                    block.way.pop(v)
                                                    # block.way.pop(len(ListOfCacheBlocks) - 1)
                                                    block.way.insert(v, address.tag)
                                                    address.numberOfWay = str(v + 1) + "\n" + "Victim tag : " + str(
                                                        victim) + " (victim) replaced with " + address.tag + " (new)"
                                        break
                    Temp.clear()
                    return True
    else:
        return False


def CheckingCache1(address, numbOfWays):  # finding block

    if not Searching1(address, numbOfWays):
        Block = CacheBlock(address.index, 1, address.tag)
        ListOfCacheBlocks.append(Block)  # Create new block.
        address.situation = "Miss"
        Block.way.append(address.tag)
        address.numberOfWay = "1"
    Show1(address)


def CheckingWays(address, block):
    for i in range(0, len(block.way)):

        if address.tag == block.way[i]:
            address.situation = "Hit"
            address.numberOfWay = str(i + 1)
            return True
    return False


def SetAssociative():  # Get inputs and change Hex address to Binary address...

    global MemorySize
    global CacheSize
    global BlockSize
    numberOfWays = waytxt.get()
    Initializing()  # Initializing variables.
    # check if the inputs are power of 2...
    if isPowerOfTwo(MemorySize) and isPowerOfTwo(CacheSize) and isPowerOfTwo(BlockSize) :

        if numberOfWays != "" :

            try:

                if isPowerOfTwo(int(numberOfWays)):

                    if MemorySize > CacheSize:
                        regex = re.findall("^0[xX].[a-fA-F0-9]*$", addresstxt.get())  # Match input with regEX.
                        if regex:
                            try:
                                Length = int(math.log2(MemorySize))  # Length of addresses in memory.
                                res = "{0:08b}".format(int(addresstxt.get(), 16))  # Code to convert hex to binary
                                # code for solving the problem of length of input address!
                                res = res[::-1]
                                for j in range(((len(addresstxt.get()) - 2) * 4) - len(res)):
                                    res = res + str(0)
                                res = res[::-1]
                                # code for adding 0 to the address.
                                if len(res) < Length:
                                    res = res[::-1]
                                    for x in range(Length - len(res)):
                                        res = res + str(0)
                                    res = res[::-1]
                                elif len(res) > Length:
                                    res = res[len(res) - Length:len(res)]  # if the address is long.

                                Separation1(res, len(res), CacheSize, BlockSize, numberOfWays)
                                memorytxt.configure(state="disable")  # Disable all entries to be unchangeable during execution.
                                cachetxt.configure(state="disable")
                                blocktxt.configure(state="disable")
                                waytxt.configure(state="disable")
                                formatcb1.configure(state="disable")
                                formatcb2.configure(state="disable")
                                rad1.configure(state="disable")
                                rad2.configure(state="disable")
                                rad3.configure(state="disable")
                            except ValueError:
                                messagebox.showerror(title="Error", message="Address is not valid !")
                        else:
                            messagebox.showerror(title="Address is not valid !", message="Please use (0x) at the "
                                                                                        "first of your input or "
                                                                                        "enter valid input.")
                    else:
                        messagebox.showerror(title="Error", message="Memory must be greater than cache !")
                        memorytxt.delete(0, END)
                        cachetxt.delete(0, END)
                else:
                    messagebox.showerror(title="Error", message="Number of ways is not power of 2 !")
                    waytxt.delete(0, END)  
            except ValueError:
                messagebox.showerror(title="Error", message="Number of ways is not valid !")
                waytxt.delete(0, END)  
        else:
            messagebox.showerror(title="Error", message="Enter number of ways !")
            waytxt.delete(0, END)        
    else:
        if memorytxt.get() != "" and cachetxt.get() != "" and blocktxt.get() != "":
            messagebox.showerror(title="Error", message="Some of the inputs are not power of 2...!")
        MemorySize = 0
        CacheSize = 0
        BlockSize = 0
    addresstxt.delete(0, END)
    addresstxt.insert(0, "0x")


def TimeCalculation(event=""):  # Calculate access time.

    if cacheTimetxt.get() != "" and penaltyTimetxt.get() != "":  # check if we have inputs...
        if len(ListOfAddresses) != 0:
            c = 0  # Number of hits.
            for address in ListOfAddresses:
                if address.situation == "Hit":
                    c = c + 1
            HitRate = float(c / len(ListOfAddresses))
            MissRate = float(1 - HitRate)
            AccessTime = (float(cacheTimetxt.get()) + MissRate * float(penaltyTimetxt.get()))

            txt = "Effective time is : " + str(AccessTime) + " ns"
            messagebox.showinfo(title="Time", message=txt)
        else:
            messagebox.showerror(title="Error", message="There is not any address...!")
    else:
        messagebox.showerror(title="Error", message="Enter the time inputs !")


def Step(event=""):

    if selected.get() == 1:
        DirectMap()
    elif selected.get() == 2:
        FullyAssociative()
    elif selected.get() == 3:
        SetAssociative()
    else:
        messagebox.showerror(title="Error", message="Please choose a mapping algorithm !")


def Clear(event=""):  # clear the cache and entries....

    global MemorySize
    global CacheSize
    global BlockSize
    global numberOfSets
    if len(ListOfAddresses) > 0:
        res = messagebox.askquestion('Reset Application', 'Do you want to clear everything ?')     
        if res == 'yes' :     
            InfoSA.clear()
            InfoFA.clear()
            InfoDM.clear()
            ListOfAddresses.clear()
            ListOfCacheBlocks.clear()
            memorytxt.configure(state="normal")
            cachetxt.configure(state="normal")
            blocktxt.configure(state="normal")
            rad1.configure(state="normal")
            rad2.configure(state="normal")
            rad3.configure(state="normal")
            formatcb1.configure(state="readonly")
            formatcb2.configure(state="readonly")
            memorytxt.delete(0, END)
            cachetxt.delete(0, END)
            blocktxt.delete(0, END)
            addresstxt.delete(0, END)
            addresstxt.insert(0, "0x")
            cacheTimetxt.delete(0, END)
            penaltyTimetxt.delete(0, END)
            if selected.get() == 3:
                waytxt.configure(state="normal")
                waytxt.delete(0, END)
            else:
                pass
    else:
        messagebox.showerror(title="Error", message="Cache is empty !")

    if MemorySize != 0 and CacheSize != 0 and BlockSize != 0:  # It is for when enter sizes and calculate them but
        MemorySize = 0  # there is not any address input, so we need to
        CacheSize = 0  # change the values.
        BlockSize = 0
        numberOfSets = 0


def Save(event=""):
    try:
        now = datetime.now()
        nowStr = str(now)
        files = [('Text Document', '*.txt')]
        name=asksaveasfile(filetypes = files, mode='w',defaultextension=".txt")
        if selected.get() == 1:

            name.write("Now: " + nowStr + "\n")
            name.write("\nDirect Map" + "\n")
            for i in range(0, len(InfoDM)):
                name.write("\n" + "\n" + str(i+1) + ". " + InfoDM[i])
            name.close

        elif selected.get() == 2:

            name.write("Now: " + nowStr + "\n")
            name.write("\nFully Associative" + "\n")
            for i in range(0, len(InfoFA)):
                name.write("\n" + "\n" + str(i+1) + ". " + InfoFA[i])
            name.close

        elif selected.get() == 3:

            name.write("Now: " + nowStr + "\n")
            name.write("\nSet Associative" + "\n")
            for i in range(0, len(InfoSA)):
                name.write("\n" + "\n" + str(i+1) + ". " + InfoSA[i])
            name.close

        else:
            messagebox.showerror(title="Error", message="No information exists !")
            name.close
    except AttributeError:
        pass


# GUI:
if __name__ == "__main__":

    def AboutFrame():
        root = Toplevel(window)  
        root.resizable(0, 0)
        root.geometry('520x180+400+250')
        root.title("About")
        root.configure(bg='#ffffff')
        photo1 = PhotoImage(file ="1.png")
        root.iconphoto(False, photo1)
        canvas = Canvas(root, width = 120, height = 100, bg="white")      
        canvas.place(x=25, y=30)
        img = PhotoImage(file="4.png")      
        canvas.create_image(15,12, anchor=NW, image=img) 
        txt = "Cache Simulator 2" + "\n" + "\nDeveloped by Alireza Pashm Foroush" + "\n" + "Student of Shahid Chamran University of Ahvaz" + \
            "\n" + "\nalireza1610@gmail.com" 
        txtlbl = Label(root, text=txt, fg='#32004d', bg='#ffffff', font="Arial 10 bold")
        txtlbl.place(x=170, y=30)
        mainloop()   
        
    def WhatsNew():
        messagebox.showinfo(title="Updated", message="Cache Simulator" + "\n" + " V1.0 ➜ V2.0" + 
        "\n" + "\n" + "Last updated 15 July 2020" + "\n" + "\n" + "What's new:" + "\n" + "\n" + "  ★ New GUI." +"\n" + 
        "  ★ Fixed known bugs." + "\n" + "  ★ Two new algorithms, Fully Associative and Set Associative, are now added." + 
        "\n" + "  ★ Way text box is added for Set Associative algorithm." + "\n" + 
        "  ★ New Menubar is also added." + "\n" + "  ★ You can save the information on a text file, just go to File on Menubar." +"\n" +
        "\nFor more information go to Menubar > Help > User Guide.")

    def Appear():
        string = waytxt.get() 
        if string == "Maximum" or string == "1" or string == "":
            waytxt.configure(state="normal")
            waytxt.delete(0, END)
        else:
            waytxt.configure(state="normal")

    def Disappear2():
        waytxt.configure(state="normal")
        waytxt.delete(0, END)
        waytxt.insert(0, "Maximum") 
        waytxt.configure(state="disable")

    def Disappear1():
        waytxt.configure(state="normal")
        waytxt.delete(0, END)
        waytxt.insert(0, "1") 
        waytxt.configure(state="disable")
        
    def OpenPdf(event=""):
        file ="User's Guide.pdf"
        os.startfile(file)

    def Exit(event=""): 
        res = messagebox.askquestion('Exit Application', 'Do you want to exit ?')     
        if res == 'yes' : 
            sys.exit()  
        else : 
            pass
        
    #Main Frame:
    window = Tk()
    window.geometry('1000x665+165+10')
    window.title("Cache Simulator")
    window.resizable(0, 0)
    window.configure(bg='#ffffff')
    photo1 = PhotoImage(file = "1.png")
    window.iconphoto(False, photo1)
    selected = IntVar()

    img = PhotoImage(file="24.png")
    albl = Label(window, image=img)
    albl.place(x=560, y=-5)

    window.bind('<Control-r>', Clear)
    window.bind('<Control-q>', Exit)
    window.bind('<Control-s>', Save)
    window.bind('<F1>', OpenPdf)
    window.bind('<F10>', Step)
    window.bind('<F11>', TimeCalculation)

    #Menubar:
    menu = Menu(window)
    item = Menu(menu, tearoff=0)
    item1 = Menu(menu, tearoff=0)

    menu.add_cascade(label='File', menu=item)
    menu.add_cascade(label='Help', menu=item1)

    window.config(menu=menu)
    item.add_command(label='Save information as ...', accelerator="Ctrl+S", command = lambda : Save())
    item.add_command(label='Reset', accelerator="Ctrl+R", command=Clear)
    item.add_separator()  
    item.add_command(label='Exit', command=Exit, accelerator="Ctrl+Q")
    item1.add_command(label='User Guide...', accelerator="F1", command = lambda : OpenPdf())
    item1.add_command(label="What's New in this version...", command = lambda : WhatsNew())
    item1.add_separator()  
    item1.add_command(label='About...', command = lambda : AboutFrame())

    # Labels:
    memorylbl = Label(window, text="Memory Size", fg='#210033', bg='#ffffff', font="Arial 10 bold")
    memorylbl.place(x=66, y=30)
    cachelbl = Label(window, text="Cache Size", fg='#210033', bg='#ffffff', font="Arial 10 bold")
    cachelbl.place(x=66, y=90)
    blocklbl = Label(window, text="Block Size", fg='#210033', bg='#ffffff', font="Arial 10 bold")
    blocklbl.place(x=66, y=150)
    waylbl = Label(window, text="Way", fg='#210033', bg='#ffffff', font="Arial 10 bold")
    waylbl.place(x=66, y=210)
    addresslbl = Label(window, text="Address", fg='#210033', bg='#ffffff', font="Arial 10 bold")
    addresslbl.place(x=66, y=270)
    cacheTimelbl = Label(window, text="Algorithm", fg='#210033', bg='#ffffff', font="Arial 10 bold")
    cacheTimelbl.place(x=66, y=330)
    cacheTimelbl = Label(window, text="Cache Access Time", fg='#11001a', bg='#ffffff', font="Arial 10 bold")
    cacheTimelbl.place(x=66, y=500)
    penaltyTimelbl = Label(window, text="Penalty Miss Time", fg='#11001a',bg='#ffffff', font="Arial 10 bold")
    penaltyTimelbl.place(x=276, y=500)

    # Text Boxes:
    frame1 = Frame(window, background = '#530080', borderwidth = 1, relief = FLAT)
    memorytxt = Entry(frame1, width=28,relief=FLAT, font="Arial 10 bold", fg="#210033",  bg="white")
    memorytxt.pack()
    frame1.place(x=70, y=60)

    frame2 = Frame(window, background = '#530080', borderwidth = 1, relief = FLAT)
    cachetxt = Entry(frame2, width=28, relief=FLAT, font="Arial 10 bold", fg="#210033", bg="white")
    cachetxt.pack()
    frame2.place(x=70, y=120)

    frame3 = Frame(window, background = '#530080', borderwidth = 1, relief = FLAT)
    blocktxt = Entry(frame3, width=58, relief=FLAT, font="Arial 10 bold", fg="#210033", bg="white")
    blocktxt.pack()
    frame3.place(x=70, y=180)

    frame4 = Frame(window, background = '#530080', borderwidth = 1, relief = FLAT)
    waytxt = Entry(frame4, width=58, font="Arial 10 bold", relief=FLAT, fg="#210033", bg="white")
    waytxt.pack()
    frame4.place(x=70, y=240)

    frame5 = Frame(window, background = '#530080', borderwidth = 1, relief = FLAT)
    addresstxt = Entry(frame5, width=58, relief=FLAT, font="Arial 10 bold", fg="#210033", bg="white")
    addresstxt.pack()
    frame5.place(x=70, y=300)
    addresstxt.insert(0, "0x")

    frame6 = Frame(window, background = '#420066', borderwidth = 1, relief = FLAT)
    cacheTimetxt = Entry(frame6, width=28, relief=FLAT, font="Arial 10 bold", fg="#210033", bg="white")
    cacheTimetxt.pack()
    frame6.place(x=70, y=530)

    frame7 = Frame(window, background = '#420066', borderwidth = 1, relief = FLAT)
    penaltyTimetxt = Entry(frame7, width=28, relief=FLAT, font="Arial 10 bold", fg="#210033", bg="white")
    penaltyTimetxt.pack()
    frame7.place(x=280, y=530)

    # Combo boxes:
    frame8 = Frame(window, background = '#630196', borderwidth = 1, relief = FLAT)
    formatcb1 = Combobox(frame8, state="readonly", width=30, font="Arial 8 bold")
    formatcb1['values'] = ("KB", "MB", "GB")
    formatcb1.pack()
    frame8.place(x=278, y=60)

    frame9 = Frame(window, background = '#630196', borderwidth = 1, relief = FLAT)
    formatcb2 = Combobox(frame9, state="readonly", width=30, font="Arial 8 bold")
    formatcb2['values'] = ("KB", "MB")
    formatcb2.pack()
    frame9.place(x=278, y=120)

    # Buttons;
    rad1 = Radiobutton(window, text='Direct Map', bg='#ffffff', activeforeground="#400061", activebackground="white", value=1, fg='#11001a', font="Arial 9 bold", variable=selected, command=Disappear1)
    rad1.place(x=70, y=360)
    rad2 = Radiobutton(window, text='Fully Associative', bg='#ffffff', activeforeground="#400061", activebackground="white", value=2, fg='#11001a', font="Arial 9 bold", variable=selected, command=Disappear2)
    rad2.place(x=70, y=395)
    rad3 = Radiobutton(window, text='Set Associative', relief=FLAT, bg='#ffffff', activeforeground="#400061", activebackground="white", fg='#11001a', font="Arial 9 bold", value=3, variable=selected, command=Appear)
    rad3.place(x=70, y=430)
    stepbtn = Button(window, text="Step", activebackground="#65009c", width=16, height=1, relief=FLAT, bg='#360054', font="Arial 11 bold", fg='white', command=Step)
    stepbtn.place(x=200, y=455)
    calculatebtn = Button(window, text="Calculate", height=1, width=16, activebackground="#65009c", relief=FLAT, bg='#360054', font="Arial 11 bold", fg='white', command=TimeCalculation)   
    calculatebtn.place(x=200, y=575)
    frame10 = Frame(window, background = '#420066', borderwidth = 2, relief = FLAT)
    clearbtn = Button(frame10, text="Reset", bg='white', activebackground="white", height=-1, relief=FLAT, width=17,  font="Arial 10 bold", fg='#360054', command=Clear)
    clearbtn.pack()
    frame10.place(x=715, y=525)
    exitbtn = Button(window, text="Exit", width=16, activebackground="#65009c", relief=FLAT, height=1, bg="#360054", font="Arial 11 bold", fg='white', command=Exit)
    exitbtn.place(x=713, y=567)
    aboutbtn = Button(window, text="About", width=5, activebackground="white", relief=FLAT, height=1, bg="white", font="Arial 10 bold", fg='#530080', command=AboutFrame)
    aboutbtn.place(x=438, y=5)

    window.after(2000, lambda : WhatsNew())
    window.mainloop()
    